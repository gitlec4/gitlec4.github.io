<!doctype html>
<html lang="ko">
 <head>
  <meta charset="UTF-8">
  <title>폼메일</title>
 </head>
 <body>
  <h1>Contact</h1>
  <?php
  if (isset($_REQUEST['email']))  {
	  // Email 정보
	  $admin_email = "jjane0625@naver.com";
	  $email = $_REQUEST['email'];
	  $subject = $_REQUEST['subject'];
	  $comment = $_REQUEST['comment'];

	  // 메일 보내기
	  mail($admin_email, "$subject", $comment, "From:" . $email);
	  
	  // Email response
	  echo " 연락주셔서 감사합니다. ";  
  }
  else  {
?>
 <form method="post">
  Email: <input name="email" type="text" placeholder="당신의 메일 주소를 넣어주세요." /><br />
  Subject: <input name="subject" type="text" /><br />
  Message:<br />
  <textarea name="comment" rows="15" cols="40"></textarea><br />
  <input type="submit" value="Submit" />
  </form>
<?php
  }
?>
 </body>
</html>